<?php
class ControllerExtensionModuleDboptim extends Controller {
	public function index() {
		$data = array();
		
		$result = $this->db->query('show tables');
		$data['tables'] = array();
		
		foreach ($result->rows as $row) {
			$data['tables'][ $row[key($row)] ] = null;
		}
		
// 		if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($_POST['optimize']) && is_array($_POST['optimize']) && ! empty($_POST['optimize'])) {
// 			foreach($_POST['optimize'] as $table) {
					foreach ($data['tables'] as $table => $value) {
						$result = $this->db->query('optimize table '. $table);
						
						$data['tables'][$table] = $result->rows[0]['Msg_text'];
					}
// 			}
// 		}
		
		$this->load->language('extension/module/dboptim');
		
		$this->document->setTitle($this->language->get('heading_title'));
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/dboptim', 'user_token=' . $this->session->data['user_token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/dboptim', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}
		
		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('extension/module/dboptim', 'user_token=' . $this->session->data['user_token'], true);
		} else {
			$data['action'] = $this->url->link('extension/module/dboptim', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], true);
		}

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);

		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/dboptim', $data));
	}
	
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/dboptim')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}