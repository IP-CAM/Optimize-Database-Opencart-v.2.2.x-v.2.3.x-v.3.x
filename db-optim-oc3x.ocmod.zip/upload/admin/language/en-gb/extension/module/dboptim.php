<?php

$_['heading_title'] 			= 'DB Optimize';

$_['text_optimize_tables'] = 'Whenever you access this page the database optimizer runs, <b>OK</b> means the table has just been optimized';
$_['text_optimize_selected_tables'] = 'Optimize Selected Tables';
$_['text_table'] 					= 'Table';
$_['text_result'] 				= 'Result';
$_['text_extension'] 			= 'Extensions';