<?php

$_['heading_title'] = 'DB Optimize';

$_['text_optimize_tables'] = 'Sempre que você acessa esta página o otimizador de banco de dados é executado, se esta recebendo <b>OK</b> em algumas tabelas, significa que a tabela acabou de ser otimizada';
$_['text_optimize_selected_tables'] = 'Otimizar tabelas selecionadas';
$_['text_table'] 			= 'Tabela';
$_['text_result'] 		= 'Resultado';
$_['text_extension'] 			= 'Extensões';