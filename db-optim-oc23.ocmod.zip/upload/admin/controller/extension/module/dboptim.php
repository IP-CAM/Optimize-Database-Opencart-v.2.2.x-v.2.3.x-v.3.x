<?php
class ControllerExtensionModuleDboptim extends Controller
{
	public function index() {
		$data = array();
		
		$result = $this->db->query('show tables');
		$data['tables'] = array();
		
		foreach ($result->rows as $row) {
			$data['tables'][ $row[key($row)] ] = null;
		}
		
// 		if ($this->request->server['REQUEST_METHOD'] == 'POST' && isset($_POST['optimize']) && is_array($_POST['optimize']) && ! empty($_POST['optimize'])) {
// 			foreach($_POST['optimize'] as $table) {
				foreach ($data['tables'] as $table => $value) {
					$result = $this->db->query('optimize table '. $table);
					
					$data['tables'][$table] = $result->rows[0]['Msg_text'];
				}
// 			}
// 		}
		
		$this->load->language('extension/module/dboptim');
		
		$this->document->setTitle($this->language->get('heading_title'));
		
		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_optimize_selected_tables'] = $this->language->get('text_optimize_selected_tables');
		$data['text_optimize'] = $this->language->get('text_optimize');
		$data['text_table'] = $this->language->get('text_table');
		$data['text_result'] = $this->language->get('text_result');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true)
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/dboptim', 'token=' . $this->session->data['token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/dboptim', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}
		
		$data['action'] = $this->url->link('extension/module/dboptim', 'token=' . $this->session->data['token'], true);
		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=module', true);
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/module/dboptim', $data));
	}
}