<?php

$_['heading_title'] = 'DB Optimize';

$_['text_optimize_selected_tables'] = 'Otimizar tabelas selecionadas!';
$_['text_optimize'] 	= 'Sempre que você acessa esta página o otimizador de banco de dados é executado, receber um <b>OK</b> significa que a tabela acabou de ser otimizada';
$_['text_table'] 			= 'Tabela';
$_['text_result'] 		= 'Resultado';